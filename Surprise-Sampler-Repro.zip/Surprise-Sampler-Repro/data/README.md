# data/

本目录存放**论文报告数值的对照文件**，不存放原始图像或原始评分。

| 文件 | 内容 |
|---|---|
| `reference_results.json` | 论文正文与图注中出现的每一个数值：图像计数、计算指标均值、学生评分均值、两个混合模型、专家方差分析与 Tukey HSD、稳健性、相关分析、信度。 |

## 用途

1. `scripts/verify_reference.py` 读取该文件，用**可由汇总值确定性反算**的关系重算一遍
   （例如由 F 与自由度反算 p 值与 η²、由 q 反算 Tukey p、由 r 反算 r²），逐条给出 PASS/FAIL。
2. `scripts/demo_scores_from_reference.py` 用这些均值合成一份模拟评分表与模拟指标表，
   让第 3、4 阶段在没有 GPU、没有原始数据时也能跑通。

## 关于原始数据

论文中该研究声明的公开仓库地址为：

```
https://github.com/zx13913865173-Guns/Surprise-in-Sampling-How-Five-Diffusion-Samplers-Influence-Perceived-Novelty-
```

按论文 2.1 节，2,834 张图中有 126 条提示词（1,890 张图）**不进入任何分析**，
仅保留在公开仓库中供再分析。原始评分表（768 条学生评分、720+720 条专家评分）
应在伦理与知情同意允许的范围内，以匿名 ID 形式一并提供。

把真实的 `images/`、`scores/*.csv`、`ratings/*.csv` 放入对应 `outputs/` 子目录后，
第 3、4 阶段脚本会自动改用真实数据，无需改代码。
