# When Surprise Does Not Predict Value —— 复现工程

复现论文 **《When Surprise Does Not Predict Value: Computational Metrics and Human
Judgments of Diffusion-Generated Art》**（Xin Zhang, Dmitry Galkin, Tomsk State
University）的完整流程与代码。

论文比较八个 SDXL 采样器（Euler a、DPM++ 2M Karras、LMS、Heun、DDIM、DPM2 a、
KDPM2 Ancestral、UniPC）在 150 条抽象提示词上的计算指标与人类评分，共生成
**2,834 张图**，并用学生（4 人 × 192 图）与专家（8 人 × 90 图）评分检验
「感知惊喜度」与「创造价值」是否一致。

---

## 一、工程结构

```
Surprise-Sampler-Repro/
├── configs/                    实验参数
│   ├── experiment.yaml         四组实验的规模、种子、SDXL 生成参数
│   ├── samplers.yaml           八个采样器 → diffusers 调度器的映射
│   └── rating_schema.yaml      学生 5 维 / 专家 3 题的评分表与量表范围
├── prompts/                    提示词清单
│   ├── abstract_prompts_150.json   150 条抽象概念提示词（24 条为分析集）
│   ├── analysis_prompts_24.json    进入分析的 24 条提示词
│   └── prompt_types_20.json        实验 C 的 20 条基础提示词 × 2 种类型
├── src/
│   ├── utils.py                路径、配置、参考值读取
│   ├── generation/             第 1-2 阶段
│   │   ├── manifest.py             提示词清单 → 逐图任务，强制核对图像数
│   │   └── generate_diffusers.py   用 Diffusers 按采样器生成图像
│   ├── evaluation/             第 3 阶段：计算指标
│   │   ├── lpips_distance.py       种子间 LPIPS 距离
│   │   ├── niqe_brisque.py         无参考质量指标 NIQE / BRISQUE
│   │   ├── clip_score.py           图文一致度 CLIP Score
│   │   ├── fid.py                  集合级 FID（三个代表采样器）
│   │   ├── dreamsim_diversity.py   种子间 DreamSim 多样性
│   │   └── laplacian_variance.py   拉普拉斯方差（清晰度）
│   ├── rating/                 评分汇总与信度
│   │   ├── reliability.py          Cronbach α、ICC(2,k)
│   │   └── rating_io.py            评分长表 → 图像级均值
│   └── analysis/               第 4 阶段：统计建模与绘图
│       ├── inference.py            混合模型的 F 检验（显式分母自由度）
│       ├── sampler_metrics.py      采样器级指标聚合 + 对齐矩阵
│       ├── student_model.py        M1 / M2 混合模型与事后比较
│       ├── expert_anova.py         专家一元方差分析与 Tukey HSD
│       ├── correlations.py         三个相关检验（BH 校正）
│       ├── experiment_c.py         实验 C 的 PromptType × Sampler 模型
│       ├── robustness.py           模型版本 / CFG / 步数稳健性
│       └── figures.py              重绘 Fig.2-Fig.5
├── scripts/
│   ├── run_pipeline.py             一键跑第 3-4 阶段
│   ├── demo_scores_from_reference.py  由论文报告值反解生成演示数据
│   ├── fit_clarity_offsets.py      反解 M2 的清晰度组均值偏移（见 docs）
│   └── verify_reference.py         论文报告值的确定性反算核对
├── data/
│   ├── reference_results.json  论文报告的每个数值（null = 未报告）
│   └── README.md               参考值的来源与口径
├── docs/
│   ├── known_inconsistencies.md    论文内部互斥的数值与本工程的取舍
│   └── statistical_conventions.md  统计口径（自由度、R²、BH、Tukey）
└── outputs/                    运行产物
    ├── manifests/              四个实验的逐图任务清单（jsonl）
    ├── images/                 生成图像（需 GPU，当前为空）
    ├── scores/                 计算指标 CSV
    ├── ratings/                评分长表与图像级均值
    ├── tables/                 统计结果表
    └── figures/                Fig.2-Fig.5
```

## 二、运行方式

**环境依赖**

```bash
pip install -r requirements.txt            # 第 1、3、4 阶段
pip install -r requirements-generation.txt # 第 2 阶段（需要 GPU）
```

**四阶段流程**

```bash
# 阶段 1：展开逐图任务清单，并核对四组实验的图像数（2250+144+240+200=2834）
python -m src.generation.manifest --verify

# 阶段 2：生成图像（需 GPU 与 diffusers；本工程不附带原始图像）
python -m src.generation.generate_diffusers --experiment original experiment_a

# 阶段 3：计算指标（逐图 / 逐对）
python -m src.evaluation.clip_score --manifest outputs/manifests/original.jsonl \
    --out outputs/scores/clip_original.csv
python -m src.evaluation.lpips_distance --images outputs/images/original \
    --out outputs/scores/lpips_original.csv
# 其余指标脚本见 src/evaluation/*.py 的 docstring；均可加 --self-test 自检

# 阶段 4：统计建模与绘图（7 步）
python scripts/run_pipeline.py

# 论文报告值的反算核对（不依赖数据）
python scripts/verify_reference.py
```

**没有原始图像与评分数据时**，用演示数据跑通第 3-4 阶段：

```bash
python scripts/demo_scores_from_reference.py   # 由论文报告值反解生成评分与指标
python scripts/run_pipeline.py                 # 输出表格与图件
```

或一步完成：`python scripts/run_pipeline.py --with-demo`。

## 三、数据可用性

工作区内**没有**论文的原始图像、原始评分表与计算指标 CSV，因此本工程：

- 把论文报告的每个数值集中收录在 `data/reference_results.json`，供核对与反解使用；
- 提供 `scripts/demo_scores_from_reference.py`，以「让复现脚本算出论文报告值」为
  目标反解生成参数，合成一份可跑通第 3-4 阶段的演示数据；
- 一旦把真实数据放入 `outputs/`（`images/`、`scores/`、`ratings/`），流水线会自动
  使用真实数据，无需修改代码。

演示数据与论文的差异、以及论文内部互斥的数值，全部记录在
`docs/known_inconsistencies.md`。

## 四、复现结论

- `scripts/verify_reference.py`：**PASS 29 / FAIL 0 / WARN 7**（共 36 项）。7 项 WARN
  全部来自论文内部数值的舍入不一致（Tukey q 与 p 不能互算、由 F 反推的 q 与报告的 q
  不等），不是本工程的数据问题，详见 `docs/statistical_conventions.md`。
- 演示数据下第 3-4 阶段 7 步全部跑通，输出见 `outputs/tables/` 与 `outputs/figures/`。
- 完全对齐论文的：学生 M1 的 F(7,184) = 2.41 与 p = 0.022；专家两个一元方差分析
  F(2,87) = 4.12 / 4.18、η² = 0.087 / 0.088；三个相关（0.183 / 0.319 / 0.214，BH 校正后
  p = 0.011 / <0.001 / 0.004）；信度（专家 ICC 0.88 / 0.90、α 0.87）；实验 C 的
  F(4,171) = 1.63、F(1,171) = 0.47；稳健性检查（−0.4、+0.3、ρ = 0.86 / 0.79）。
- 无法同时满足的：M2 的采样器效应 F（论文 2.18，演示数据 ~3.0）与 M1 的条件 R²
  （论文 0.16，演示数据 0.08），原因见 `docs/known_inconsistencies.md`。
